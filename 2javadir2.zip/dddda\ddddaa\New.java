public class New {
	public static void main(String[] args) {
		
	}
}