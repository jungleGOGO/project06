public class 1New {
	public static void main(String[] args) {
		
	}
}